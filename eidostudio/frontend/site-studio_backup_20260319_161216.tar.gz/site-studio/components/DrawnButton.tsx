import React from 'react';
import styled from 'styled-components';

interface DrawnButtonProps {
  text: string;
  onClick?: () => void;
  variant?: 'primary' | 'dark' | 'light';
  className?: string;
}

const DrawnButton: React.FC<DrawnButtonProps> = ({
  text,
  onClick,
  variant = 'primary',
  className = '',
}) => {
  return (
    <StyledWrapper className={className}>
      <a
        href="#"
        className={`button type--${variant}`}
        onClick={e => {
          e.preventDefault();
          if (onClick) onClick();
        }}
      >
        <div className="button__line" />
        <div className="button__line" />
        <span className="button__text">{text}</span>
        <div className="button__drow1" />
        <div className="button__drow2" />
      </a>
    </StyledWrapper>
  );
};

const StyledWrapper = styled.div`
  display: inline-block;

  .type--primary {
    --line_color: #ffffff;
    --back_color: #1a1a1a;
  }

  .type--dark {
    --line_color: #1a1a1a;
    --back_color: #f23db3;
  }

  .type--light {
    --line_color: #f23db3;
    --back_color: #ffffff;
  }

  .button {
    position: relative;
    z-index: 0;
    width: 280px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    font-size: 14px;
    font-weight: 800;
    color: var(--line_color);
    letter-spacing: 2px;
    transition: all 0.3s ease;
    font-family: 'Inter', sans-serif;
    text-transform: uppercase;
  }

  .button__text {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 100%;
    z-index: 2;
  }

  .button::before,
  .button::after,
  .button__text::before,
  .button__text::after {
    content: '';
    position: absolute;
    height: 3px;
    border-radius: 2px;
    background: var(--line_color);
    transition: all 0.5s ease;
  }

  .button::before {
    top: 0;
    left: 54px;
    width: calc(100% - 56px * 2 - 16px);
  }

  .button::after {
    top: 0;
    right: 54px;
    width: 8px;
  }

  .button__text::before {
    bottom: 0;
    right: 54px;
    width: calc(100% - 56px * 2 - 16px);
  }

  .button__text::after {
    bottom: 0;
    left: 54px;
    width: 8px;
  }

  .button__line {
    position: absolute;
    top: 0;
    width: 56px;
    height: 100%;
    overflow: hidden;
  }

  .button__line::before {
    content: '';
    position: absolute;
    top: 0;
    width: 150%;
    height: 100%;
    box-sizing: border-box;
    border-radius: 300px;
    border: solid 3px var(--line_color);
  }

  .button__line:nth-child(1),
  .button__line:nth-child(1)::before {
    left: 0;
  }

  .button__line:nth-child(2),
  .button__line:nth-child(2)::before {
    right: 0;
  }

  .button:hover {
    letter-spacing: 4px;
  }

  .button:hover::before,
  .button:hover .button__text::before {
    width: 8px;
  }

  .button:hover::after,
  .button:hover .button__text::after {
    width: calc(100% - 56px * 2 - 16px);
  }

  .button__drow1,
  .button__drow2 {
    position: absolute;
    z-index: -1;
    border-radius: 16px;
    transform-origin: 16px 16px;
  }

  .button__drow1 {
    top: -16px;
    left: 40px;
    width: 32px;
    height: 0;
    transform: rotate(30deg);
  }

  .button__drow2 {
    top: 44px;
    left: 77px;
    width: 32px;
    height: 0;
    transform: rotate(-127deg);
  }

  .button__drow1::before,
  .button__drow1::after,
  .button__drow2::before,
  .button__drow2::after {
    content: '';
    position: absolute;
  }

  .button__drow1::before {
    bottom: 0;
    left: 0;
    width: 0;
    height: 32px;
    border-radius: 16px;
    transform-origin: 16px 16px;
    transform: rotate(-60deg);
  }

  .button__drow1::after {
    top: -10px;
    left: 45px;
    width: 0;
    height: 32px;
    border-radius: 16px;
    transform-origin: 16px 16px;
    transform: rotate(69deg);
  }

  .button__drow2::before {
    bottom: 0;
    left: 0;
    width: 0;
    height: 32px;
    border-radius: 16px;
    transform-origin: 16px 16px;
    transform: rotate(-146deg);
  }

  .button__drow2::after {
    bottom: 26px;
    left: -40px;
    width: 0;
    height: 32px;
    border-radius: 16px;
    transform-origin: 16px 16px;
    transform: rotate(-262deg);
  }

  .button__drow1,
  .button__drow1::before,
  .button__drow1::after,
  .button__drow2,
  .button__drow2::before,
  .button__drow2::after {
    background: var(--back_color);
  }

  .button:hover .button__drow1 {
    animation: drow1 ease-in 0.06s;
    animation-fill-mode: forwards;
  }

  .button:hover .button__drow1::before {
    animation: drow2 linear 0.08s 0.06s;
    animation-fill-mode: forwards;
  }

  .button:hover .button__drow1::after {
    animation: drow3 linear 0.03s 0.14s;
    animation-fill-mode: forwards;
  }

  .button:hover .button__drow2 {
    animation: drow4 linear 0.06s 0.2s;
    animation-fill-mode: forwards;
  }

  .button:hover .button__drow2::before {
    animation: drow3 linear 0.03s 0.26s;
    animation-fill-mode: forwards;
  }

  .button:hover .button__drow2::after {
    animation: drow5 linear 0.06s 0.32s;
    animation-fill-mode: forwards;
  }

  @keyframes drow1 {
    0% {
      height: 0;
    }
    100% {
      height: 100px;
    }
  }
  @keyframes drow2 {
    0% {
      width: 0;
      opacity: 0;
    }
    10% {
      opacity: 0;
    }
    11% {
      opacity: 1;
    }
    100% {
      width: 120px;
    }
  }
  @keyframes drow3 {
    0% {
      width: 0;
    }
    100% {
      width: 80px;
    }
  }
  @keyframes drow4 {
    0% {
      height: 0;
    }
    100% {
      height: 120px;
    }
  }
  @keyframes drow5 {
    0% {
      width: 0;
    }
    100% {
      width: 124px;
    }
  }
`;

export default DrawnButton;
