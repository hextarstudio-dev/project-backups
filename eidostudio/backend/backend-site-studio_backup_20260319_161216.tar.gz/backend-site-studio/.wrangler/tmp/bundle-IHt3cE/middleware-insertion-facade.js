				import worker, * as OTHER_EXPORTS from "D:\\Design Gráfico 2026\\Clientes\\Fevereiro\\Eidos-Studio\\site-eidos-studio\\eidosbackendworker\\src\\bootstrap-r2.ts";
				import * as __MIDDLEWARE_0__ from "D:\\Design Gráfico 2026\\Clientes\\Fevereiro\\Eidos-Studio\\site-eidos-studio\\eidosbackendworker\\node_modules\\wrangler\\templates\\middleware\\middleware-ensure-req-body-drained.ts";

				export * from "D:\\Design Gráfico 2026\\Clientes\\Fevereiro\\Eidos-Studio\\site-eidos-studio\\eidosbackendworker\\src\\bootstrap-r2.ts";
				const MIDDLEWARE_TEST_INJECT = "__INJECT_FOR_TESTING_WRANGLER_MIDDLEWARE__";
				export const __INTERNAL_WRANGLER_MIDDLEWARE__ = [
					
					__MIDDLEWARE_0__.default
				]
				export default worker;